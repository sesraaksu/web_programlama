﻿using System;

namespace DenizKabugu.Areas.Identity.Pages.Account
{
    internal class PhoneNumberAttribute : Attribute
    {
    }
}